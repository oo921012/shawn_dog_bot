# 🐾 shawn的狗 LINE 防翻群機器人

這是一個使用 **Python + Flask + LINE Messaging API SDK** 製作的群組管理機器人。

## ✨ 功能
- 防踢人 / 防邀請 / 防網址
- 管理員系統 / 黑名單
- 全體標記 / 抽獎
- 自動簽到 / 潛水名單
- 成員備份

## 🚀 部署步驟（Render 免費版）
1️⃣ 登入 [https://render.com](https://render.com)  
2️⃣ 建立新 Web Service  
3️⃣ 上傳此專案資料夾（解壓 ZIP）  
4️⃣ Runtime 選 **Python 3**  
5️⃣ Start Command:
